<?php
//*por si quiere saltarse el inicio de sesion e ir a la url y navegar desde ahi por las paginas, este codigo le llevara devuelta a login
session_start();
include 'conexion.php';
if (!isset($_SESSION['usuario'])) {
    echo '<script>alert("Por favor debes iniciar sesión");
        window.location="login.php";
        </script>';
    session_destroy();
    die();
}
// aqui rcopilamos datos que nos envia el archivo crearArticulo
if ($_POST) {
    // Procesar datos aquí
    $titulo = $_POST['crud-titulo'];
    $descripcion = $_POST['crud-desc'];
    $insertar = "INSERT INTO articulos (id, titulo, descripcion) VALUES(NULL, '$titulo', '$descripcion')";
    $resultadoInsert = mysqli_query($conn, $insertar);
}

if ($_GET) {
    $id = $_GET['borrar'];
    $borrar = "DELETE FROM articulos WHERE articulos.id =" . $id;
    $resultadoBorrar = mysqli_query($conn, $borrar);
}

$seleccionarTodoBd = "SELECT * FROM articulos";
$resultado = mysqli_query($conn, $seleccionarTodoBd);
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template para practicar</title>
    <link rel="icon" type="favicon/x-icon" href="assets/img/supertux.png">
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">


<body>
    <header id="header">
        <div id="contenedor">
            <div id="logo">
                <span class="gear icon">S</span>
                <p>BLOG</p>
            </div>

            <input type="checkbox" id="check">
            <label for="check" class="checkbtn">
                <i class="fa-solid fa-bars fa-2xl"></i>
            </label>

            <nav id="menu">
                <ul class="flex-ul">
                    <li><a href="bienvenido.php">INICIO</a></li>
                    <li><a href="crearArticulo.php">CREAR ARTICULO</a></li>
                    <li><a href="cerrar-sesion.php">CERRAR SESION</a></li>

                </ul>
            </nav>


        </div>
    </header>
    <main>
        <div class="centrar">
            <section id="banner">
                <header>
                    <h1>Proyecto HTML, CSS, PHP, MYSQL - Arath Abello</h1>
                </header>
            </section>
            <div class="flex mb">
                <article class="card">
                    <!-- fontwebsymbol son los iconos que descargue y que tienen sus propias letras para mostrar los iconos -->
                    <span class="icon">H</span>
                    <header>
                        <h2>Desarrollo web</h2>
                    </header>
                    <p>Aprende los principales lenguajes para desarrollar sitios web ¡Conviertete en un desarrollador
                        frontend!</p>
                </article>
                <article class="card">
                    <span class="icon">_</span>
                    <header>
                        <h2>Sistemas operativos</h2>
                    </header>
                    <p>Aprende a administrar sistemas Linux y Windows</p>
                </article>
                <article class="card">
                    <span class="icon">S</span>
                    <header>
                        <h2>Hardware</h2>
                    </header>
                    <p>Aprende características poco conocidas del hardware</p>
                </article>
                <article class="card">
                    <span class="icon">u</span>
                    <header>
                        <h2>Redes e internet</h2>
                    </header>
                    <p>Aprende a configurar y administrar redes informaticas y servidores</p>
                </article>
                <article class="card">
                    <span class="icon">a</span>
                    <header>
                        <h2>Bases de datos</h2>
                    </header>
                    <p>Aprende a montar y administrar base de datos</p>
                </article>
            </div>


            <section class="contenido-articulos">
                <header class="section-header">
                    <h2>ARTICULOS</h2>
                </header>
                <div>
                    <?php foreach ($resultado as $proyecto) { ?>
                        <article class="card card-articulo">
                            <header class="article-header">
                                <h3><?php echo $proyecto['titulo']; ?></h3>
                            </header>
                            <p><?php echo $proyecto['descripcion']; ?></p>
                            <a href="?borrar=<?php echo $proyecto['id'] ?>">Borrar</a>
                        </article>
                    <?php } ?>
                </div>

            </section>
        </div>
    </main>

    <footer>
        <div class="contenedor-footer">
            <div class="contenedor-ul">
                <h2>MENÚ</h2>
                <ul class="menu-footer">
                    <li class="item-footer"><a class="link-footer" href="bienvenido.php">Inicio</a></li>
                    <li class="item-footer"><a class="link-footer" href="crearArticulo.php">Crear articulo</a></li>
                    <li class="item-footer"><a class="link-footer" href="cerrar-sesion.php">Cerrar sesión</a></li>
                </ul>
            </div>

            <div class="contenedor-ul">
                <h2>Lengueajes</h2>
                <ul class="menu-footer">
                    <li class="item-footer">HTML</li>
                    <li class="item-footer">CSS</li>
                    <li class="item-footer">JAVASCRIPT</li>
                    <li class="item-footer">PHP</li>
                    <li class="item-footer">MYSQL</li>
                </ul>
            </div>

            <div class="contenedor-iframe-footer">
                <h2>¿DÓNDE ESTAMOS??</h2>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3329.5359015141166!2d-70.64573968493075!3d-33.43534200412286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9662c598506488df%3A0xc4261233e54747ba!2sMuseo%20Nacional%20de%20Bellas%20Artes!5e0!3m2!1ses-419!2scl!4v1675203364688!5m2!1ses-419!2scl" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>


        </div>
    </footer>
</body>

</html>