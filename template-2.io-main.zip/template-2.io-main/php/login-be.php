<?php

session_start();

if (isset($_SESSION['usuario'])) {
    header("location: bienvenido.php");
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <link rel="icon" type="favicon/x-icon" href="assets/img/supertux.png">
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>

<body>
    

    <main class="login-flex-main">
        <section id="section-login">
        <header class="header-login">
                <img class="user-img" src="../assets/img/usuario.png" alt="es una imagen de usuario">
                <h1>Inicia sesión</h1>
            </header>
            <form class="login-form" action="login.php" method="post">
                <div class="mb">
                    <label class="logueo" for="logueo-sesion">Email</label>
                    <div>
                        <input required type="email" name="correo_usuario" id="logueo-sesion" placeholder="Ingresar email">
                        <span></span>
                    </div>
                </div>
                <div class="mb">
                    <label for="contrasenia">
                        Contraseña
                    </label>
                    <div>
    
                        <input required type="password" name="password_usuario" id="logueo-password" placeholder="Ingresar contraseña">
                        <span></span>
                    </div>
                </div>
                <input type="submit" value="Iniciar sesión">
                <span>¿No tienes una cuenta? Registrate <a href="../index.html">AQUI</a></span>
            </form>
        </section>
    </main>
</body>

</html>