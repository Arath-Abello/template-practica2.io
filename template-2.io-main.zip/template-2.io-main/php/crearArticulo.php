<?php 
    session_start();
    include 'conexion.php';
    if(!isset($_SESSION['usuario'])){
        echo '<script>alert("Por favor debes iniciar sesión");
        window.location="login.php";
        </script>';
        session_destroy();
        die();
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear articulo</title>
    <link rel="icon" type="favicon/x-icon" href="assets/img/supertux.png">
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
</head>
<body>
<header id="header">
        <div id="contenedor">
            <div id="logo">
                <span class="gear icon">S</span>
                <p>BLOG</p>
            </div>

            <input type="checkbox" id="check">
            <label for="check" class="checkbtn">
                <i class="fa-solid fa-bars fa-2xl"></i>
            </label>
    
            <nav id="menu">
                <ul class="flex-ul">
                    <li><a href="bienvenido.php">INICIO</a></li>
                    <li><a href="crearArticulo.php">CREAR ARTICULO</a></li>
                    <li><a href="cerrar-sesion.php">CERRAR SESION</a></li>
                    
                </ul>
            </nav>
            
            
        </div>
    </header>

    <main class="login-flex-main">
        <section class="section-crear">
            <header>
                <h1 class="centrar">crea tu articulo</h1>
            </header>
            <form class="form-crear" action="bienvenido.php" method="post">
                <div class="mb">
                    <label for="titulo">
                    Titulo
                    </label>
                    <input type="text" id="titulo" name="crud-titulo" >
                </div>
    
                <div class="mb">
                    <label for="desc">
                        Descripción
                    </label>
                    <input type="text" id="desc" name="crud-desc" >
                </div>
                <input type="submit" value="Crear">
            </form>
        </section>
    </main>

    <footer>
        <div class="contenedor-footer">
            <ul class="menu-footer">
                <li class="item-footer"><a class="link-footer" href="bienvenido.php">Inicio</a></li>
                <li class="item-footer"><a class="link-footer" href="crearArticulo.php">Crear articulo</a></li>
                <li class="item-footer"><a class="link-footer" href="cerrar-sesion.php">Cerrar sesión</a></li>
            </ul>

            <div class="contenedor-iframe-footer">
                <h2>¿Dónde estamos?</h2>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3329.5359015141166!2d-70.64573968493075!3d-33.43534200412286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9662c598506488df%3A0xc4261233e54747ba!2sMuseo%20Nacional%20de%20Bellas%20Artes!5e0!3m2!1ses-419!2scl!4v1675203364688!5m2!1ses-419!2scl" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>


        </div>
    </footer>
</body>
</html>