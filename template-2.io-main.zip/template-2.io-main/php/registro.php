<?php

    //* aqui incluiremos la conexion a la base de datos para poder ejecutar el sql
    include 'conexion.php';

    //* recogemos los datos del registro enviados 
    $nombreDelUsuario = $_POST['nombre_usuario'];
    $correoUsuario = $_POST['correo_usuario'];
    $apodoUsuario = $_POST['apodo_usuario'];
    $passwordUsuario = $_POST['password_usuario'];

    
    // *validamos que los inputs enviados no esten vacios y si se cumplen entonces ejecutamos el sql
    if(!empty($nombreDelUsuario) && !empty($correoUsuario) && !empty($apodoUsuario) && !empty($passwordUsuario)){
         //* encriptar la contraseña para que sea más segura y en la base de datos se muestre encriptada
    //* utiliza el Bcrypt que es el más recomendado para proteger contraseñas 
    $passwordUsuario = password_hash($passwordUsuario, PASSWORD_BCRYPT); 

        //* variable donde almacena código sql para insertar dentro de la tabla usuarios y relacionando las columnas y los datos recogidos por post guardado en sus variables correspondientes
        $sql = "INSERT INTO usuarios(nombre, correo, usuario, password) VALUES('$nombreDelUsuario', '$correoUsuario', '$apodoUsuario', '$passwordUsuario')";
    
        //*selecciona todo de la tabla usuarios y busca una coincidencia con el valor de la columna correo que tiene almacenado los valores sacados de la variable $correoUsuario.
        $verificar_correo = mysqli_query($conn, "SELECT * FROM usuarios WHERE correo='$correoUsuario'");
        
        // *luego de seleccionar todo entonces verificamos las filas donde haya un correo identico con otro
        if(mysqli_num_rows($verificar_correo)>0){
            echo 'El correo ya existe, Intenta con otro correo diferente';

            //* para que se detenga y no ejecute las demás lineas de código
            exit();
        }

        $verificarNombreUsuario = mysqli_query($conn, "SELECT * FROM usuarios WHERE usuario='$apodoUsuario'");
        
        if(mysqli_num_rows($verificarNombreUsuario)>0){
            echo 'El nombre de usuario ya existe, Intenta con otro usuario diferente';

            exit();
        }

        //*ingresar a la conexion y ejecutar el sql
        $ejecutar = mysqli_query($conn, $sql);

        if($ejecutar){
            echo '<script>alert("usuario registrado exitosamente");
            window.location="login-be.php";
            </script>';
        }else{
            echo '<script>alert("No fue posible registrar el usuario");</script>';
        }

        
    }else{
        echo "debe completar todos los campos";
    }

    // para no dejar la conexion abierta y que no consuma recursos
    mysqli_close($conn);

    ?>
