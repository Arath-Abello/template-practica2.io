<?php

    session_start();

    include 'conexion.php';

    $correo = $_POST['correo_usuario'];
    $contrasena = $_POST['password_usuario'];

    //*    obtener la contraseña encriptada almacenda en la base de datos
    $sql = "SELECT password FROM usuarios WHERE correo = '$correo'";

    //*ejecutamos
    $resultado = mysqli_query($conn, $sql);
    //* para obtener una fila de resultados como una matriz asociativa
    $fila = mysqli_fetch_assoc($resultado);

    //* se accede al valor de la columna 'password' en el array $fila y se asigna a la variable $password_hash
    $password_hash = $fila['password'];
    
    //* verificar si la contraseña es valida
if (password_verify($contrasena, $password_hash)) {
    $_SESSION['usuario'] = $correo;
    echo '<script>alert("Bienvenido al sitio web crea tu articulo :)");
        window.location="bienvenido.php";
    </script>';
    exit();
} else {
    echo '<script>alert("Usuario o contraseña incorrectos");
        window.location="login-be.php";
    </script>';
    exit();
}


?>