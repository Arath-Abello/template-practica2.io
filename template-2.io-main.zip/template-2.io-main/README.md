# template-2.io
segundo proyecto que hice en vacaciones donde se hizo un registro y login de usuario usando php y mysql y usando un poco de javascript para alerts usando html y css
